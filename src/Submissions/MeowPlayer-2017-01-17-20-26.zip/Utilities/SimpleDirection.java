package Utilities;

/**
 * Created by Cassi on 1/13/2017.
 */
public enum SimpleDirection {North, South, East, West, NorthEast, NorthWest, SouthEast, SouthWest}
