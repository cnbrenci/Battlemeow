package MeowMovement;

import battlecode.common.MapLocation;

/**
 * Created by Cassi on 1/16/2017.
 *
 * Unused currently. I think it'd be good to use an array of these instead of 2 arrays coordinating indexes
 * but I haven't replaced it yet.
 */
public class PotentialMove {
    MapLocation potentialMoveLocation;
    double distanceToDestination;
    public PotentialMove() {
    }
}
